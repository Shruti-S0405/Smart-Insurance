import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app.routes'; //
import { AuthModule } from '@auth0/auth0-angular';
import { AppComponent } from './app.component';
import { InsuranceClaimComponent } from './insurance-claim/insurance-claim.component';
import { HeaderComponent } from "./header/header.component";

@NgModule({
  declarations: [
    AppComponent,
    InsuranceClaimComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule, // Import routing module if you use it
    AuthModule.forRoot({
        domain: 'dev-k1nosdcwl88uskcx.us.auth0.com', // Replace with your Auth0 domain
        clientId: 'FymGp4gYalxGNUSuHZFEOwguICJehRps', // Replace with your Auth0 client ID
        authorizationParams: {
            redirect_uri: window.location.origin, // Redirect URI after login
        }
    }),
    HeaderComponent
],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
