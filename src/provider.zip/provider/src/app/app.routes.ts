import { Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { InsuranceClaimComponent } from './insurance-claim/insurance-claim.component';
import { LoginComponent } from './login/login.component';
const routes: Routes = [
//   { path: '', redirectTo: 'login', pathMatch: 'full' },  // Redirect to login as the default route
  { path: '', component: LoginComponent },
  { path: 'provider', component: InsuranceClaimComponent },          // Login route
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
