import { Component } from '@angular/core';

@Component({
  selector: 'app-insurance-claim',
  templateUrl: './insurance-claim.component.html',
  styleUrls: ['./insurance-claim.component.css']
})
export class InsuranceClaimComponent {
  selectedFile: File | null = null;
  successMessage: string = ''; // Property to hold the success message

  onFileChange(event: any) {
    if (event.target.files && event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
    }
  }

  onSubmit() {
    if (this.selectedFile) {
      // Here you would normally handle form submission
      // For now, we'll just display a success message
      this.successMessage = 'Submitted successfully'; // Update the success message
    }
  }
}
